import os
from pyrogram import Client, filters

BOT_TOKEN = os.getenv("BOT_TOKEN")
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")

app = Client("filetolinkbot", bot_token=BOT_TOKEN, api_id=API_ID, api_hash=API_HASH)

@app.on_message(filters.command("start") & filters.private)
async def start(client, message):
    await message.reply_text("Salut! Je suis ton bot FileToLink, prêt à t’aider.")

@app.on_message(filters.command("help") & filters.private)
async def help(client, message):
    await message.reply_text("Envoie un fichier, je te renvoie un lien direct.")

@app.on_message(filters.document | filters.video | filters.audio | filters.photo)
async def handle_file(client, message):
    await message.reply_text(f"J'ai reçu ton fichier : {message.document.file_name if message.document else 'fichier'}")

if __name__ == "__main__":
    app.run()